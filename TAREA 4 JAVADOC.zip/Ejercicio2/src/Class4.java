/**
 * 
 * @author Carlos
 * @version laquetuquieras
 *
 */
public class Class4 {
	public void method() {
		int a = anotherClass.innerClass.i;
		 int b = a + anotherClass.intValue();
		}
}
