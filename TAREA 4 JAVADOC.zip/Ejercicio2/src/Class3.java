
/**
 * 
 * @author Carlos
 * @version laquetuquieras
 *
 */
public class Class3 {
	public int add(int a, int b) {
		return a+b;
	}
	public void method() {
		 int a=1;
		 int b=2;
		
		 int d=add(a,add(a,b));
		}
}
