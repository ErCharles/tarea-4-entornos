/**
 * 
 * @author Carlos
 * @version laquetuquieras
 *
 */
public class Circulo {
	
	/**
	 * @param centroX coordenada X del circulo
	 * @param centroY coordenada Y del circulo
	 * @param radio radio del circulo
	 * 
	 */
	
	private double centroX;
	private double centroY;
	private double radio;
	 
	 /**
	  * Le entrega los parametros a:
	  * @param cx centroX
	  * @param cy centroY
	  * @param r radio
	  */
	 
	 public Circulo(double cx, double cy, double r) {
	 centroX = cx;
	 centroY = cy;
	 radio = r;
	 }
	 /**
	  * devuelve los datos del centroX
	  * @return
	  */
	 public double getCentroX() {
	 return centroX;
	 }
	 /**
	  *  formula para sacar el pertimetro dela circunferencia
	  * @return
	  */
	 public double getCircunferencia() {
	 return 2 * Math.PI * radio;
	 }
	 /**
	  * Dar forma al objeto 
	  * @param deltaX
	  * @param deltaY
	  */
	 public void mueve(double deltaX, double deltaY) {
	 centroX = centroX + deltaX;
	 centroY = centroY + deltaY;
	 }
	 /**
	  * Toma el tama�o
	  * @param s
	  */
	 public void escala(double s) {
	 radio = radio * s;
	 }
}
