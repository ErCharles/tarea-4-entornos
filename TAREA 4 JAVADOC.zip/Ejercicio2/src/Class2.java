
import java.util.ArrayList;
/**
 * 
 * @author Carlos
 * @version laquetuquieras
 *
 */
public class Class2 {
	AnotherClass anotherClass;
	private int numero =anotherClass.intValue();
	 public void method() {
	 int c = b + (2* numero);
	 }
}
