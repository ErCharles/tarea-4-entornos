/**
 * 
 * @author Carlos
 * @version laquetuquieras
 *
 */
public class Profesor extends Persona{
	
	public Profesor(String numeroDeTelefono,  String str, int edad){
	super(numeroDeTelefono, str, edad);
	}
	
	public void printInformacionPersonal(){
		System.out.println("Nombre: " + str);
		System.out.println("Edad: " + edad);
		System.out.println("Telefono: "+ this.numeroDeTelefono);
	}
}
