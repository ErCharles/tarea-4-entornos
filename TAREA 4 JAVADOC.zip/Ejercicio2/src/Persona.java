/**
 * 
 * @author Carlos
 * @version laquetuquieras
 *
 */
public class Persona {
	
	String str;
	int edad;
	String numeroDeTelefono;
	
	public Persona(String numeroDeTelefono, String str, int edad){
		this.numeroDeTelefono=numeroDeTelefono;
		this.str= str;
		this.edad=edad;
	}
	public String getNumeroDeTelefono(){
		return numeroDeTelefono;
	}
}
