import java.util.ArrayList;

/**
 * 
 * @author Carlos
 * @version laquetuquieras
 *
 */
public class Class {
	private static final String CADENA = "string";
	
	public void method() {
	 ArrayList list = new ArrayList();
	 list.add(CADENA);
	 anotherMethod(CADENA);
	}
	 private void anotherMethod(String string) {
	 }
}
